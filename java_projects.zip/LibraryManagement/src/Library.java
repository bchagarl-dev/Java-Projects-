import java.util.*;

public class Library {
    private List<String> books = new ArrayList<>();

    public void addBook(String book) { books.add(book); }
    public void printBooks() {
        System.out.println("Books in library:");
        books.forEach(System.out::println);
    }
}
