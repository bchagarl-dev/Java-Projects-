import java.util.*;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook("Java Basics");
        library.addBook("Data Structures");
        library.printBooks();
    }
}
